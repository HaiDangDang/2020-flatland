# Local treeobservations observation fc-net experiments

## Method

TODO

## Results

|            | Mean score | Mean norm. score | Mean % completed|
| ---------- |:----------:|:----------------:|:---------------:|
| FullyConnected [256,256] |   |             |               |

(*preliminary*)

## Plots

![](plots/fc_256.png)

(*preliminary*)

## Conclusion

TODO

## Refrences

TODO
